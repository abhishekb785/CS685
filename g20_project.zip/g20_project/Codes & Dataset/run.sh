python3 merge.py
python3 price.py
python cluster.py
python prog.py
python analysis.py
